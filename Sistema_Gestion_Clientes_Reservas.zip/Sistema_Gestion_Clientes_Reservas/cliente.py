import re
from entidades import Entidad


class Cliente(Entidad):

    def __init__(self, identificador, nombre, documento, telefono, correo):
        super().__init__(identificador)

        self.nombre = self.validar_nombre(nombre)
        self.documento = self.validar_documento(documento)
        self.telefono = self.validar_telefono(telefono)
        self.correo = self.validar_correo(correo)

    def validar_nombre(self, nombre):
        if not isinstance(nombre, str) or len(nombre.strip()) < 3:
            raise ValueError("El nombre debe tener al menos 3 caracteres.")
        return nombre.strip()

    def validar_documento(self, documento):
        documento = str(documento).strip()

        if not documento.isdigit() or len(documento) < 5:
            raise ValueError("El documento debe contener al menos 5 dígitos.")

        return documento

    def validar_telefono(self, telefono):
        telefono = str(telefono).strip()

        if not telefono.isdigit() or len(telefono) < 7:
            raise ValueError("El teléfono debe contener al menos 7 dígitos.")

        return telefono

    def validar_correo(self, correo):
        if not isinstance(correo, str):
            raise ValueError("El correo debe ser texto.")

        patron = r"^[\w.+-]+@[\w-]+\.[\w.-]+$"

        if not re.match(patron, correo):
            raise ValueError("El correo electrónico no es válido.")

        return correo

    def mostrar_informacion(self):
        return (
            f"Cliente: {self.nombre}\n"
            f"Documento: {self.documento}\n"
            f"Teléfono: {self.telefono}\n"
            f"Correo: {self.correo}"
        )