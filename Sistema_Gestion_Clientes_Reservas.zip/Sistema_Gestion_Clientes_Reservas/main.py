from cliente import Cliente
from servicios import (
    ReservaSala,
    AlquilerEquipos,
    AsesoriaEspecializada
)
from reservas import GestorReservas
from excepciones import ErrorReserva


# CREACIÓN DE CLIENTES

cliente1 = Cliente(
    "C001", "Ana López", "12345678",
    "3001234567", "ana@gmail.com"
)

cliente2 = Cliente(
    "C002", "Carlos Pérez", "87654321",
    "3101234567", "carlos@gmail.com"
)

cliente3 = Cliente(
    "C003", "María Torres", "11223344",
    "3201234567", "maria@gmail.com"
)


# CREACIÓN DE SERVICIOS

sala = ReservaSala(
    "S001", "Sala de reuniones",
    "Sala equipada para reuniones", 50000
)

equipo = AlquilerEquipos(
    "S002", "Computador portátil",
    "Alquiler de computador", 30000
)

asesoria = AsesoriaEspecializada(
    "S003", "Asesoría informática",
    "Asesoría especializada en sistemas", 80000
)


# GESTIÓN DE RESERVAS

gestor = GestorReservas()

print("\n===== SISTEMA DE GESTIÓN =====")


# OPERACIONES EXITOSAS

print("\n--- OPERACIONES EXITOSAS ---")

gestor.crear_reserva(cliente1, sala, 2)
gestor.crear_reserva(cliente2, equipo, 3)
gestor.crear_reserva(cliente3, asesoria, 1)

gestor.confirmar_reserva(1)
gestor.cancelar_reserva(2)
gestor.confirmar_reserva(3)


# OPERACIONES FALLIDAS

print("\n--- OPERACIONES FALLIDAS ---")

try:
    gestor.confirmar_reserva(2)
except ErrorReserva as error:
    print("Error controlado:", error)

try:
    gestor.cancelar_reserva(2)
except ErrorReserva as error:
    print("Error controlado:", error)

try:
    gestor.buscar_reserva(99)
except ErrorReserva as error:
    print("Error controlado:", error)

try:
    gestor.crear_reserva(cliente1, sala, -5)
except ErrorReserva as error:
    print("Error controlado:", error)


# LISTADO FINAL

print("\n===== LISTADO FINAL DE RESERVAS =====")

gestor.listar_reservas()

print("\nEl sistema finalizó correctamente.")
