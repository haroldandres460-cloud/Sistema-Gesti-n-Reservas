from abc import ABC, abstractmethod
from entidades import Entidad


class Servicio(Entidad, ABC):

    def __init__(self, identificador, nombre, descripcion, tarifa):
        super().__init__(identificador)

        if not isinstance(nombre, str) or not nombre.strip():
            raise ValueError("El nombre del servicio es obligatorio.")

        if not isinstance(tarifa, (int, float)) or isinstance(tarifa, bool) or tarifa <= 0:
            raise ValueError("La tarifa debe ser mayor que cero.")

        self.nombre = nombre.strip()
        self.descripcion = descripcion
        self.tarifa = tarifa

    @abstractmethod
    def calcular_costo(self, duracion):
        pass

    @abstractmethod
    def describir_servicio(self):
        pass

    def mostrar_informacion(self):
        return self.describir_servicio()

    def validar_parametros(self, duracion):
        if not isinstance(duracion, (int, float)) or isinstance(duracion, bool) or duracion <= 0:
            raise ValueError("La duración debe ser mayor que cero.")
        return True


class ReservaSala(Servicio):

    def calcular_costo(self, duracion):
        self.validar_parametros(duracion)
        return self.tarifa * duracion

    def describir_servicio(self):
        return f"Reserva de sala: {self.nombre}"


class AlquilerEquipos(Servicio):

    def calcular_costo(self, duracion):
        self.validar_parametros(duracion)
        return self.tarifa * duracion * 1.10

    def describir_servicio(self):
        return f"Alquiler de equipos: {self.nombre}"


class AsesoriaEspecializada(Servicio):

    def calcular_costo(self, duracion):
        self.validar_parametros(duracion)
        return self.tarifa * duracion * 1.20

    def describir_servicio(self):
        return f"Asesoría especializada: {self.nombre}"
    