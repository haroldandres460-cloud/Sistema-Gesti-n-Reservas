class ErrorReserva(Exception):
    pass


class DatosReservaError(ErrorReserva):
    pass


class ReservaNoEncontradaError(ErrorReserva):
    pass


class EstadoReservaError(ErrorReserva):
    pass