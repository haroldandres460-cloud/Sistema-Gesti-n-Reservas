from abc import ABC, abstractmethod


class Entidad(ABC):

    def __init__(self, identificador):
        if not identificador or not str(identificador).strip():
            raise ValueError("El identificador no puede estar vacío.")

        self.__identificador = str(identificador).strip()

    @property
    def identificador(self):
        return self.__identificador

    @abstractmethod
    def mostrar_informacion(self):
        pass