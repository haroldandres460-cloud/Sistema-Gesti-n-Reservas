import logging
import logs

from excepciones import (
    ErrorReserva,
    DatosReservaError,
    ReservaNoEncontradaError,
    EstadoReservaError
)

from cliente import Cliente
from servicios import Servicio


class Reserva:

    contador = 0

    def __init__(self, cliente, servicio, duracion):

        if not isinstance(cliente, Cliente):
            raise DatosReservaError("Debe ingresar un cliente válido.")

        if not isinstance(servicio, Servicio):
            raise DatosReservaError("Debe ingresar un servicio válido.")

        if (
            not isinstance(duracion, (int, float))
            or isinstance(duracion, bool)
            or duracion <= 0
        ):
            raise DatosReservaError(
                "La duración debe ser un número mayor que cero."
            )

        Reserva.contador += 1

        self.codigo = Reserva.contador
        self.cliente = cliente
        self.servicio = servicio
        self.duracion = duracion
        self.estado = "Pendiente"

        logging.info("Reserva %s creada correctamente.", self.codigo)

    def confirmar(self):

        if self.estado != "Pendiente":
            raise EstadoReservaError(
                "Solo se pueden confirmar reservas pendientes."
            )

        self.estado = "Confirmada"

        logging.info("Reserva %s confirmada.", self.codigo)

        return f"Reserva {self.codigo} confirmada correctamente."

    def cancelar(self):

        if self.estado == "Cancelada":
            raise EstadoReservaError(
                "La reserva ya se encuentra cancelada."
            )

        self.estado = "Cancelada"

        logging.info("Reserva %s cancelada.", self.codigo)

        return f"Reserva {self.codigo} cancelada correctamente."

    def calcular_total(self):
        return self.servicio.calcular_costo(self.duracion)

    def mostrar_informacion(self):

        return (
            f"Código: {self.codigo}\n"
            f"Cliente: {self.cliente.nombre}\n"
            f"Servicio: {self.servicio.nombre}\n"
            f"Duración: {self.duracion} horas\n"
            f"Costo total: ${self.calcular_total():,.0f}\n"
            f"Estado: {self.estado}"
        )


class GestorReservas:

    def __init__(self):
        self.reservas = []

    def crear_reserva(self, cliente, servicio, duracion):

        try:
            nueva_reserva = Reserva(cliente, servicio, duracion)
            self.reservas.append(nueva_reserva)

        except ErrorReserva as error:
            logging.error("Error al crear reserva: %s", error)
            raise

        else:
            print("Reserva creada exitosamente.")
            print(nueva_reserva.mostrar_informacion())
            return nueva_reserva

        finally:
            logging.info("Finalizó el proceso de creación de reserva.")

    def buscar_reserva(self, codigo):

        for reserva in self.reservas:
            if reserva.codigo == codigo:
                return reserva

        raise ReservaNoEncontradaError(
            f"No se encontró la reserva con código {codigo}."
        )

    def confirmar_reserva(self, codigo):

        try:
            reserva = self.buscar_reserva(codigo)
            mensaje = reserva.confirmar()

        except ErrorReserva as error:
            logging.error("Error al confirmar reserva: %s", error)
            raise

        else:
            print(mensaje)
            return reserva

        finally:
            logging.info("Finalizó el proceso de confirmación.")

    def cancelar_reserva(self, codigo):

        try:
            reserva = self.buscar_reserva(codigo)
            mensaje = reserva.cancelar()

        except ErrorReserva as error:
            logging.error("Error al cancelar reserva: %s", error)
            raise

        else:
            print(mensaje)
            return reserva

        finally:
            logging.info("Finalizó el proceso de cancelación.")

    def listar_reservas(self):

        if not self.reservas:
            print("No hay reservas registradas.")
            return

        print("\n===== LISTADO DE RESERVAS =====")

        for reserva in self.reservas:
            print(reserva.mostrar_informacion())
            print("----------------------------")
            